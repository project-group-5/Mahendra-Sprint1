package com.SeatBookingProject.SeatClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeatClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeatClassApplication.class, args);
	}

}
