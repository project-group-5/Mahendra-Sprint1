package com.SeatBookingProject.SeatClass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatClassApplicationTests {

	@Test
	void contextLoads() {
	}

}
